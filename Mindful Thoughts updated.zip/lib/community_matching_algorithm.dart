import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(MyApp());
}

class CommunityMatchingAlgorithm {
  // Function to calculate the compatibility score between two users
  static double calculateCompatibilityScore(
      Map<String, dynamic> user1, Map<String, dynamic> user2) {
    // Replace this with your actual scoring logic based on user interests and mental health conditions
    double interestsScore =
        calculateInterestsScore(user1['interests'], user2['interests']);
    double conditionScore =
        calculateConditionScore(user1['condition'], user2['condition']);
    return (interestsScore + conditionScore) / 2.0;
  }

  // Function to calculate the score for interests compatibility between two users
  static double calculateInterestsScore(
      List<String> interests1, List<String> interests2) {
    // Replace this with your actual scoring logic for interests compatibility
    int commonInterests =
        interests1.toSet().intersection(interests2.toSet()).length;
    int totalInterests = max(interests1.length, interests2.length);
    return commonInterests.toDouble() / totalInterests.toDouble();
  }

  // Function to calculate the score for mental health condition compatibility between two users
  static double calculateConditionScore(String condition1, String condition2) {
    // Replace this with your actual scoring logic for condition compatibility
    return condition1 == condition2 ? 1.0 : 0.0;
  }

  // Function to find potential community matches for each user
  static Map<String, List<Map<String, dynamic>>> findCommunityMatches(
      List<Map<String, dynamic>> users, double minCompatibilityScore) {
    Map<String, List<Map<String, dynamic>>> communityMatches = {};

    for (int i = 0; i < users.length; i++) {
      String currentUser = users[i]['id'];
      List<Map<String, dynamic>> matches = [];

      for (int j = 0; j < users.length; j++) {
        if (i != j) {
          double compatibilityScore =
              calculateCompatibilityScore(users[i], users[j]);

          if (compatibilityScore >= minCompatibilityScore) {
            matches.add({
              'user': users[j]['id'],
              'score': compatibilityScore,
            });
          }
        }
      }

      if (matches.isNotEmpty) {
        communityMatches[currentUser] = matches;
      }
    }

    return communityMatches;
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  final List<Map<String, dynamic>> users = [
    // Replace this list with your actual user data retrieved from the data source.
    {
      "id": "user1",
      "interests": ["anxiety", "meditation", "yoga"],
      "condition": "anxiety",
    },
    {
      "id": "user2",
      "interests": ["depression", "reading", "painting"],
      "condition": "depression",
    },
    {
      "id": "user3",
      "interests": ["PTSD", "cooking", "gardening"],
      "condition": "PTSD",
    },
    // Add more user data...
  ];

  final double minCompatibilityScore = 0.5;

  @override
  Widget build(BuildContext context) {
    final Map<String, List<Map<String, dynamic>>> communityMatches =
        findCommunityMatches(users, minCompatibilityScore);

    return Scaffold(
      appBar: AppBar(
        title: Text('Community Matches'),
      ),
      body: ListView.builder(
        itemCount: communityMatches.length,
        itemBuilder: (context, index) {
          final user = communityMatches.keys.elementAt(index);
          final matches = communityMatches[user];

          return Card(
            child: Column(
              children: [
                ListTile(
                  title: Text('User: $user'),
                ),
                Column(
                  children: matches?.map((match) {
                        return ListTile(
                          title: Text('Match: ${match["user"]}'),
                          subtitle: Text(
                            'Compatibility Score: ${match["score"].toStringAsFixed(2)}',
                          ),
                        );
                      }).toList() ??
                      [], // Use an empty list if matches is null
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
