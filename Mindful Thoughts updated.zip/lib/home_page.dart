import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  final List<Map<String, dynamic>> users = [
    // Replace this list with your actual user data retrieved from the data source.
    {
      "id": "user1",
      "interests": ["anxiety", "meditation", "yoga"],
      "condition": "anxiety",
    },
    {
      "id": "user2",
      "interests": ["depression", "reading", "painting"],
      "condition": "depression",
    },
    {
      "id": "user3",
      "interests": ["PTSD", "cooking", "gardening"],
      "condition": "PTSD",
    },
    // Add more user data...
  ];

  @override
  Widget build(BuildContext context) {
    // Your widget tree for the home page...
    return Scaffold(
      appBar: AppBar(
        title: Text('My Home Page'),
        backgroundColor: Colors.blue, // Customize the app bar color
      ),
      body: Container(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Welcome to my home page!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 20),
            Image.asset(
              'assets/welcome_image.png', // Replace with your image path
              width: 200,
              height: 200,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Add functionality for the button
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.blue, // Customize the button color
              ),
              child: Text(
                'Get Started',
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
