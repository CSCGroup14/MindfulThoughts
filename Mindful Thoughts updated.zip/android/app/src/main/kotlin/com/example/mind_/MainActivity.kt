package com.example.mind_

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
